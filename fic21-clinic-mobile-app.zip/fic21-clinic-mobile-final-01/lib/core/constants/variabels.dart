class Variables {
  static const String baseUrl = 'http://192.168.18.40:8000';
}
