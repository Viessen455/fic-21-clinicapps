package com.example.flutter_ayo_sehat_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
