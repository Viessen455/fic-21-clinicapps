<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Google\Client as GoogleClient;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
class AuthController extends Controller
{
        public function googleLogin(Request $request)
    {
        // Ambil ID Token dari request frontend
        $idToken = $request->input('id_token');

        // Verifikasi ID Token menggunakan Google Client
        $client = new GoogleClient(['client_id' => env('GOOGLE_CLIENT_ID')]);
        $payload = $client->verifyIdToken($idToken);

        if (!$payload) {
            // Jika ID Token tidak valid
            return response()->json(['message' => 'Invalid ID Token'], 401);
        }

        // Cari pengguna berdasarkan email di database, atau buat jika belum ada
        $user = User::firstOrCreate(
            ['email' => $payload['email']],
            [
                'name' => $payload['name'], // Nama dari Google
                'google_id' => $payload['sub'], // Google User ID
            ]
        );

        // Login pengguna ke aplikasi menggunakan Laravel Auth
        Auth::login($user);

        // Buat token API menggunakan Laravel Sanctum
        $token = $user->createToken('GoogleLogin')->plainTextToken;

        // Kirim token ke frontend sebagai respons
        return response()->json(['token' => $token], 200);
    }
}
