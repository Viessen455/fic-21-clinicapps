<?php

namespace App\Filament\Resources\AdminResource\Pages;

use App\Filament\Resources\AdminResource;
use Filament\Resources\Pages\CreateRecord;
use Illuminate\Support\Facades\Hash;
use Illuminate\Database\Eloquent\Model;
class CreateAdmin extends CreateRecord
{
    protected static string $resource = AdminResource::class;
    protected static bool $canCreateAnother = false;
    protected function getRedirectUrl(): string
    {
        return $this->getResource()::getUrl('index');
    }

    protected function handleRecordCreation(array $data): Model
    {
        $data['password'] = Hash::make(12345678);
        $newData =[
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => $data['password'],
            'clinic_id' => $data['clinic_id'],
            'role' => 'admin',
        ];

        $admin = static::getModel()::create($newData);
        return $admin;
    }


}
